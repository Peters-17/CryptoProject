package com.atguigu.crypto.service;

import com.atguigu.crypto.model.Kline;
import com.atguigu.crypto.repository.KlineRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.List;

@Service
public class CryptoService {

    @Autowired
    private KlineRepository klineRepository;

    public ResponseEntity<String> loadData(String symbol, String interval, String startTime) {
        RestTemplate restTemplate = new RestTemplate();
        String url = String.format(
                "https://api.binance.us/api/v3/klines?symbol=%s&interval=%s&startTime=%s",
                symbol, interval, startTime);

        // 发送请求并输出响应
        ResponseEntity<String[][]> response = restTemplate.getForEntity(url, String[][].class);

        // 使用Jackson解析JSON数据
        for (String[] klineData : response.getBody()) {
            Kline kline = new Kline();
            kline.setOpenTime(Long.parseLong(klineData[0]));
            kline.setCloseTime(Long.parseLong(klineData[6]));
            kline.setOpenPrice(new BigDecimal(klineData[1].toString()));
            kline.setHighPrice(new BigDecimal(klineData[2].toString()));
            kline.setLowPrice(new BigDecimal(klineData[3].toString()));
            kline.setClosePrice(new BigDecimal(klineData[4].toString()));
            kline.setVolume(new BigDecimal(klineData[5].toString()));
            kline.setQuoteAssetVolume(new BigDecimal(klineData[7].toString()));
            kline.setNumberOfTrades(Integer.parseInt(klineData[8]));
            kline.setTakerBuyBaseAssetVolume(new BigDecimal(klineData[9].toString()));
            kline.setTakerBuyQuoteAssetVolume(new BigDecimal(klineData[10].toString()));
            kline.setSymbolKline(symbol);
            kline.setIntervalKline(interval);

            // 使用MyBatis Repository插入数据
            klineRepository.insertKline(kline);
        }

        return ResponseEntity.ok("Data loaded successfully");
    }
}
