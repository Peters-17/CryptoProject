package com.atguigu.crypto.controller;

import com.atguigu.crypto.service.CryptoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CryptoController {

    @Autowired
    private CryptoService cryptoService;

    @PostMapping("/load")
    public ResponseEntity<?> loadData(@RequestParam String symbol, @RequestParam String interval, @RequestParam String startTime) {
        if (symbol == null || symbol.trim().isEmpty()) {
            return ResponseEntity.badRequest().body("Symbol is required");
        }
        if (interval == null || interval.trim().isEmpty()) {
            return ResponseEntity.badRequest().body("Interval is required");
        }
        if (startTime == null || startTime.trim().isEmpty()) {
            return ResponseEntity.badRequest().body("Start time is required");
        }

        return cryptoService.loadData(symbol, interval, startTime);
    }
}
