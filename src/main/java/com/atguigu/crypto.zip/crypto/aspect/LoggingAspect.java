package com.atguigu.crypto.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    private static final Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

    // 定义切点监控 CryptoApplication 的 run 方法和 KlineMyBatisRepository 的 insertKline 方法
    @Pointcut("execution(* com.atguigu.crypto.CryptoApplication.run(..)) || execution(* com.atguigu.crypto.repository.KlineRepository.insertKline(..))")
    public void monitor() {}

    // 定义环绕通知来记录方法执行时间
    @Around("monitor()")
    public Object logMethodExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {
        long startTime = System.currentTimeMillis();
        Object result = joinPoint.proceed();  // 执行目标方法
        long endTime = System.currentTimeMillis();

        logger.info("{} executed in {} ms", joinPoint.getSignature(), endTime - startTime);

        return result;
    }
}
