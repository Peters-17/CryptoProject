package com.atguigu.crypto.repository;

import com.atguigu.crypto.model.Kline;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface KlineRepository {

    @Insert("INSERT INTO UIKlines (open_time, close_time, open_price, high_price, low_price, close_price, volume, quote_asset_volume, number_of_trades, taker_buy_base_asset_volume, taker_buy_quote_asset_volume, symbol_kline, interval_kline) " +
            "VALUES (#{openTime}, #{closeTime}, #{openPrice}, #{highPrice}, #{lowPrice}, #{closePrice}, #{volume}, #{quoteAssetVolume}, #{numberOfTrades}, #{takerBuyBaseAssetVolume}, #{takerBuyQuoteAssetVolume}, #{symbolKline}, #{intervalKline}) " +
            "ON DUPLICATE KEY UPDATE close_time = VALUES(close_time), open_price = VALUES(open_price), high_price = VALUES(high_price), low_price = VALUES(low_price), close_price = VALUES(close_price), volume = VALUES(volume), quote_asset_volume = VALUES(quote_asset_volume), number_of_trades = VALUES(number_of_trades), taker_buy_base_asset_volume = VALUES(taker_buy_base_asset_volume), taker_buy_quote_asset_volume = VALUES(taker_buy_quote_asset_volume)")
    public int insertKline(Kline kline);

    @Select("SELECT * FROM UIKlines WHERE symbol_kline = #{symbolKline} AND interval_kline = #{intervalKline} AND open_time = #{openTime}")
    public List<Kline> findBySymbolIntervalAndOpenTime(String symbolKline, String intervalKline, Long openTime);

    @Update("UPDATE UIKlines SET close_time = #{closeTime}, open_price = #{openPrice}, high_price = #{highPrice}, low_price = #{lowPrice}, close_price = #{closePrice}, volume = #{volume}, quote_asset_volume = #{quoteAssetVolume}, number_of_trades = #{numberOfTrades}, taker_buy_base_asset_volume = #{takerBuyBaseAssetVolume}, taker_buy_quote_asset_volume = #{takerBuyQuoteAssetVolume} " +
            "WHERE symbol_kline = #{symbolKline} AND interval_kline = #{intervalKline} AND open_time = #{openTime}")
    public int updateKline(Kline kline);

    @Delete("DELETE FROM UIKlines WHERE symbol_kline = #{symbolKline} AND interval_kline = #{intervalKline} AND open_time = #{openTime}")
    public void deleteBySymbolIntervalAndOpenTime(String symbolKline, String intervalKline, Long openTime);

    @Select("SELECT * FROM UIKlines WHERE symbol_kline = #{symbolKline} AND interval_kline = #{intervalKline} ORDER BY open_time DESC LIMIT #{limit}")
    public List<Kline> findRecentBySymbolAndInterval(String symbolKline, String intervalKline, int limit);
}



